/* eslint-disable */
/* tslint:disable */
// @ts-ignore
import icon from 'vue-svgicon'
icon.register({
  'shop': {
    width: 62,
    height: 62,
    viewBox: '0 0 62 62',
    data: '<image width="62" height="62" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD4AAAA+CAMAAABEH1h2AAAABGdBTUEAALGPC/xhBQAAACBjSFJN AAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAABxVBMVEX///////////////// //////////////////////////////////////////////////////////////////////////// ////////////////////kz7/kj3/kD3/mWb/////////////////kj7/kD7///////////////// ////kj7/kD7/////////////////////mU3/kD3/kD//kD7/kET///////////////////////// //////////////////////////////////////////////////////////////////////////// //////////////////////////////////////////////////////////////////////////// //////////////////////////////////////////////////////////////////////////// //////////////////////////////////////////////////////////////////////////// ////////////////////////////////////////////////////kD2OYNXcAAAAlXRSTlMAN6LQ 2tWmPW39eTT8PLjKJjnCvzYe+rSjqTMoQmBTBS4hsademLmTMP4qd7FE9RKtqgqBn5Eez3wMLVrZ PtgHFUwFjVVOkg7c52X2GAnwhQP0CFwd46QClPIj7QGQ818xqA0LnjLrD+K30sGdsu8XJ1istfhA +asb1mErBks4QSAWY0Z/JYI1GfuuBMzTad6J4M2RgCz81YMAAAABYktHRACIBR1IAAAAB3RJTUUH 4wwMEh40OXUtQQAAAdlJREFUSMftlmdPFEEAhkdB8bhDEGmKBRtyh4JgQcAKIk1RynHgURRQ0FMs SNNDBCsiosLj73W2kKDszlziF0P2+TJv5p0nmZ3sbFYID49NwJatSckb2LY9JTF7hw9nUhOx/QHc SEtA3wnpaRkb2JUJu/V2FgQynIrsHPBr9VzIc27yYI/O3gu+fDnu27+eAwflVIHc1yGNfhiOyOHo rz85ZnSFcFxtF0EwJMfiv/QTRnkSSkqV+ikoM8by02fWc/ac2VbAeZVdmUOwyr2uhgsq/SJcUtSX 5Rt1RdFfhUI71tReW5utu15vpwYIKXQ/NNqxieYbVrrZwi0r3W6FbIXe1gLtZuoIQ2fEjF3Qfcfa BkR7VA/fC339csXdsHFF7g0IMThkpMb7six6AF0qWwyPyLUNDx/ZV6w1M9ZtJV/s8ZMgjD5V6uJZ 2Dajz1+s3dOx/pd2ah4XGoZ7o3LdxOSU6Kk2NzH9KiJe55qfkFhIZ0vi/pk3A1bsGJ99a6W5mfmm ROR/5N1719P58PGTzv68wBe3roLRRY0uPxdf3Tp5pqWevjn1Klhy6/qgUqPHJwjURZyaxW+wLHSU oeC7Vp/74W7/bNPqon5l2vH3YiFpNa63PTw8/l9+A77W/3TjVVVtAAAAJXRFWHRkYXRlOmNyZWF0 ZQAyMDE5LTEyLTEyVDEwOjMwOjUyKzA4OjAw2+F+TQAAACV0RVh0ZGF0ZTptb2RpZnkAMjAxOS0x Mi0xMlQxMDozMDo1MiswODowMKq8xvEAAAAASUVORK5CYII="/>'
  }
})
