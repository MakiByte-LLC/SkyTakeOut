/* eslint-disable */
/* tslint:disable */
// @ts-ignore
import icon from 'vue-svgicon'
icon.register({
  'employee': {
    width: 62,
    height: 62,
    viewBox: '0 0 62 62',
    data: '<image width="62" height="62" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD4AAAA+CAMAAABEH1h2AAAABGdBTUEAALGPC/xhBQAAACBjSFJN AAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAABtlBMVEX///////////////// //////////////////////////////////////////////////////////////////////////// //////////////////////////////////////////////////////////////////////////// qlX/nU7/////////kT//kT3/kT3/kT7/////////////////kT3/kT//////////////kD3/kD3/ kD7/l0L/////////////////////////////////////////////mUD/kj7/kT7/kj7/lkP///// ////kT7/kT7/////////kD3/kD7/////////////////n0D/kT7/kT7/kT7/lT7///////////// //////////////////////////////////////////////////////////////////////////// ////mWb///////////////////////////////////////////////////////////////////// ////////////////////////////////kD2FJm6wAAAAkHRSTlMAAzNnhHlIEinK8yX1ggHG8ph7 hs/7MvQnsoxZpj/Aco0m2R+f4Q9b4z4GDesWZvrlJc47TaPDbRk4BVPyyxtHHDwK+hAL92mT1hR3 hHwiyVau0+LFqs8Uw6UGEG97dB3E5si8y+78EaQH8IOvSt8edqHNS26ZWAXTxy/YwVeoQb4k9i23 io8uIu9eK19wQA0O+RL+AAAAAWJLR0QAiAUdSAAAAAd0SU1FB+MMDBIfE4VkqWsAAAG2SURBVEjH 7ZVXV8JAEEZRsCsiiL0gdgV7xS723gv23ntX7L1//GOXGHnwkOzGc9SX3Ifs2ZlcQmZ2swqFjIzM f+HhqVSJ4eXtI2L7+oGGv1LQDgik2oQgAVsdDGhCtGLoQgF9mMDDgfAIWnEigSj3qWgghlrcWCDO fSYeMFD1BMD423piUnK40ZDyQz1Vw7UoLZ3PZGQS1Kx6mJ5vscnMzbOyHYScXEadNDcv36cgDSjk 5kUOjmI2ndzhX0LGUiDQ4gyU5ZQTKirZ9Kqv1pqAaumlq+HvqLUCddL1+gagkWyBJqCZS7S0tnG0 dzCVLogU3diZTK5d3LzbwdPDpNf28o3r+0z0f+kDLPrgkGtvD9ucgZHRMY7xCQbdNkm8qemZ2Tky JkkunRcwr3M+dWGR+AUS9aVlYIWPrAKzCmnLZg1Yt/ARM+n8hrRFuwlsuULbwI60LaMCdl2hPWCf DAfsGzbi8MjsCh2f2L8t27/4WP1EPwXOqPo5cOE+cwlcXVNsyw1w6z6ltpPPy5boCXvXDFjvBX76 QcNyRGoF/9rlEFV+fBJ5NfXzi+gJ+/r2Ti2ujIzMr/EBzrEWqTvd2VEAAAAldEVYdGRhdGU6Y3Jl YXRlADIwMTktMTItMTJUMTA6MzE6MTkrMDg6MDCybk9zAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE5 LTEyLTEyVDEwOjMxOjE5KzA4OjAwwzP3zwAAAABJRU5ErkJggg=="/>'
  }
})
