/* eslint-disable */
/* tslint:disable */
// @ts-ignore
import icon from 'vue-svgicon'
icon.register({
  'main': {
    width: 128,
    height: 128,
    viewBox: '0 0 128 128',
    data: '<image width="128" height="128" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD4AAAA+CAMAAABEH1h2AAAABGdBTUEAALGPC/xhBQAAACBjSFJN AAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAABI1BMVEX///////////////// //////////////////////////////////////////////////////////////////////////// //////////////////////////////////////////////////////////////////////////// ////////////////////qlX/kD//kT7/kT7/mUD/kD//kT7/kD3/kT7/kj3/kkn/lEL/kT3/kT3/ kT7/k0D/kT7/kD7/kT3/kkH/kkD/kkD///////////////////////////////////////////// ////////////////////////////////////////////////////////////////kD2Migq/AAAA X3RSTlMACYHH7fDvz5MUEtfpKqPLAQX4/VwQQvIoLdKoVzXKoF/Uu7WI1X/bTURKs76a8Qlqf3QU irRsgHUVH6e8sDScxpYvRDgugJ7zxPbohYI5AuvnDiZ1epW4ubrTzIp3MCXIt8QAAAABYktHRACI BR1IAAAAB3RJTUUH4wwMEhQVj/PVlQAAAQhJREFUSMft0VdTwkAUhuFYsAACGoOAgkhsWECpVrAD sStg9+P//wrirIYSMuwcLhyGfW82szPPbPasJIlEop4aGh4ZtTU3Nj4xya3tDphzTvFyFzrl9vDp 6RnIs3alJe8c4OPjfiBg2pwHFvh4EAiZNheBcA9cP30pElGXgzS+8jtAeZXE14wXWCdyNRrd2AS2 iHxbXxQgxsfjO7usRLLBJf3v+Xiq9lf6H3g8k2Xt7VN4x9ENCD84PGId5yg8bzzcCYVnDH5KuvvZ OevC03+TF7y/+OVVASiW2tOA659V5ze3d5b6/gHd0xRL/sjBi0+Wxz+XK9WXV1Nv7x/sQ/2sfH1L IpGIWh3fwLcChnMOBwAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAxOS0xMi0xMlQxMDoyMDoyMSswODow MCFCsgkAAAAldEVYdGRhdGU6bW9kaWZ5ADIwMTktMTItMTJUMTA6MjA6MjErMDg6MDBQHwq1AAAA AElFTkSuQmCC"/>'
  }
})
